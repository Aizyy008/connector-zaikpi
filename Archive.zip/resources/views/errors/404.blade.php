@extends('errors.layout')

@section('code', '404')
@section('title', 'Page not found')
@section('message', 'The page you’re looking for doesn’t exist, has moved, or belongs to a different workspace.')
